package com.itsqmet.CDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdbApplication.class, args);
	}

}
