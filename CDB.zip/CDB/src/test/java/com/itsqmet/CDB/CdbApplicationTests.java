package com.itsqmet.CDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
